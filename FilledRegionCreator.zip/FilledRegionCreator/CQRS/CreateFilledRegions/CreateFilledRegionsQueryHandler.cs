﻿using Wpf.Ui.Controls;

namespace FilledRegionCreator.CQRS;

internal class CreateFilledRegionsQueryHandler(RevitContext context) : IQueryHandler<CreateFilledRegionsQuery, CreateFilledRegionsQueryResult>
{
    public CreateFilledRegionsQueryResult Execute(CreateFilledRegionsQuery input, CancellationToken cancellationToken)
    {
        var document = context.Document;
        if (document is null)
        {
            return new("No active Revit connection", ControlAppearance.Danger);
        }
        
        var filledRegionType  = document.GetElement(input.FilledRegionTypeId) as FilledRegionType;
        var activeView = document.ActiveView;

        if(activeView is not ViewPlan)
            return new("Active view is not a plan view", ControlAppearance.Danger);

        var link = document.GetElement(input.LinkId) as RevitLinkInstance;
        var linkDoc = link.GetLinkDocument();
        var transform = link.GetTotalTransform();

        var offset = input.Offset ?? 0;

        var elements = new List<Element>();

        using var trans = new Transaction(context.Document, "CreateFilledRegions");
        trans.Start();

        foreach (var roomModel in input.RoomModels)
        {
            var room = linkDoc.GetElement(roomModel.Id) as Room;
            if (room == null)
                return new ("Room not found", ControlAppearance.Danger);

            var filledRegion = CreateFilledRegion(document, room, offset, transform, filledRegionType.Id, activeView.Id);
            if(filledRegion != null)
                elements.Add(filledRegion);
            else
                return new("Filled region creation failed", ControlAppearance.Danger);

            if (cancellationToken.IsCancellationRequested)
                return new("Operation cancelled", ControlAppearance.Caution);
        }

        trans.Commit();

        return new($"{elements.Count} filled regions created", ControlAppearance.Success);
    }

    private Element? CreateFilledRegion(Document document, Room room, double offset, Transform transform, ElementId filledRegionTypeId, ElementId viewId)
    {
        try
        {
            var roomBoundaryOptions = new SpatialElementBoundaryOptions();
            var boundarySegs = room.GetBoundarySegments(roomBoundaryOptions);

            if (boundarySegs == null || !boundarySegs.Any())
                return null;

            var offsetFeet = offset / 304.8;

            var curveLoops = new List<CurveLoop>();
            foreach (var boundary in boundarySegs)
            {
                var curveLoop = new CurveLoop();
                foreach (var segment in boundary)
                {
                    var curve = segment.GetCurve();
                    var transformedCurve = curve.CreateTransformed(transform);
                    curveLoop.Append(transformedCurve);
                }
                if (Math.Abs(offsetFeet) > 0.0001)
                {
                    try
                    {
                        var offsetLoop = CurveLoop.CreateViaOffset(curveLoop, offsetFeet, XYZ.BasisZ);
                        curveLoops.Add(offsetLoop);
                    }
                    catch (Exception offsetEx)
                    {
                        curveLoops.Add(curveLoop); 
                    }
                }
                else
                {
                    curveLoops.Add(curveLoop);
                }
            }

            return FilledRegion.Create(document, filledRegionTypeId, viewId, curveLoops);
        }
        catch 
        {
            return null;
        }
    }
}