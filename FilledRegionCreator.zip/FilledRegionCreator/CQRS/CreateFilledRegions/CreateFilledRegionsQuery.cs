﻿
using FilledRegionCreator.Models;

namespace FilledRegionCreator.CQRS;
public record CreateFilledRegionsQuery(string? FilledRegionTypeId, double? Offset, string? LinkId,  List<RoomModel> RoomModels) : IQuery<CreateFilledRegionsQueryResult>;