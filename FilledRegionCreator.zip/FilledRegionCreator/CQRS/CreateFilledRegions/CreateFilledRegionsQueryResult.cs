﻿using Wpf.Ui.Controls;

namespace FilledRegionCreator.CQRS;

public record CreateFilledRegionsQueryResult(string Message, ControlAppearance Appearance);