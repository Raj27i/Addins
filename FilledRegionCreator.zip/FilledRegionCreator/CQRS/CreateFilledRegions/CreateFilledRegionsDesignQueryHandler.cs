﻿using RevitAppFramework.Design;
using Wpf.Ui.Controls;

namespace FilledRegionCreator.CQRS;

internal class CreateFilledRegionsDesignQueryHandler() : IDesignQueryHandler<CreateFilledRegionsQuery, CreateFilledRegionsQueryResult>
{
    public CreateFilledRegionsQueryResult Execute(CreateFilledRegionsQuery input, CancellationToken cancellationToken)
    {
        return new("test message", ControlAppearance.Success);
    }
}