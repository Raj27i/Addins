﻿namespace FilledRegionCreator.CQRS;

public class GetLinksQuery : IQuery<GetLinksQueryResult>;
