﻿using FilledRegionCreator.Models;

namespace FilledRegionCreator.CQRS;

public record GetLinksQueryResult(List<LinkModel>? Links);