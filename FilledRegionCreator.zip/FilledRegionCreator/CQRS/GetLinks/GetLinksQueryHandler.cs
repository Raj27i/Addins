﻿using FilledRegionCreator.Models;

namespace FilledRegionCreator.CQRS;

public class GetLinksQueryHandler(RevitContext context) : IQueryHandler<GetLinksQuery, GetLinksQueryResult>
{
    public GetLinksQueryResult Execute(GetLinksQuery input, CancellationToken cancellationToken)
    {
        var linItems = new List<LinkModel>();
        var doc = context.Document;
        if (doc is null)
            return new([]);

        var linkInstances = new FilteredElementCollector(doc)
            .OfClass(typeof(RevitLinkInstance))
            .OfType<RevitLinkInstance>();

        foreach (var link in linkInstances)
        {
            var linkDoc = link.GetLinkDocument();
            if (linkDoc is null)
                continue;
            var linkItem = new LinkModel
            {
                Name = linkDoc.Title,
                UniqueId = link.UniqueId
            };
            linItems.Add(linkItem);
        }
        return new GetLinksQueryResult(linItems);
    }
}