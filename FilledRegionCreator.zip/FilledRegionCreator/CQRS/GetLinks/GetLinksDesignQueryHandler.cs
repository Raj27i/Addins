﻿using RevitAppFramework.Design;
using FilledRegionCreator.Models;

namespace FilledRegionCreator.CQRS;

public class GetLinksDesignQueryHandler : IDesignQueryHandler<GetLinksQuery, GetLinksQueryResult>
{
    public GetLinksQueryResult Execute(GetLinksQuery input, CancellationToken cancellationToken)
    {
        var random = new Random();
        var linkItems = new List<LinkModel>();

        for (int i = 1; i <= 2; i++)
        {
            var link = new LinkModel
            {
                UniqueId = Guid.NewGuid().ToString(),
                Name = $"Room {random.Next(1, 10)}{(char)random.Next('A', 'Z' + 1)}",
            };
            linkItems.Add(link);
        }

        return new(linkItems);
    }
}