﻿namespace FilledRegionCreator.CQRS.GetRooms;

public record GetRoomsQuery(string? Id) : IQuery<GetRoomsQueryResult>;




