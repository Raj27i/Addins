﻿using FilledRegionCreator.Models;

namespace FilledRegionCreator.CQRS.GetRooms;

public record GetRoomsQueryResult(List<RoomModel>? Rooms);