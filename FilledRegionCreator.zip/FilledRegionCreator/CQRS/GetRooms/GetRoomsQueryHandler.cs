﻿using FilledRegionCreator.Models;

namespace FilledRegionCreator.CQRS.GetRooms;

public class GetRoomsQueryHandler(RevitContext context) : IQueryHandler<GetRoomsQuery, GetRoomsQueryResult>
{
    public GetRoomsQueryResult Execute(GetRoomsQuery input, CancellationToken cancellationToken)
    {
        if (string.IsNullOrEmpty(input.Id))
            return new ([]);

        var doc = context.Document;
        if (doc is null)
            return new([]);

        var activeView = doc.ActiveView;

        var linkInstance = doc.GetElement(input.Id) as RevitLinkInstance;
        var linkDoc = linkInstance?.GetLinkDocument();

        var roomItems = GetVisibleRoomsFromLink(doc, activeView, linkInstance);

        return new(roomItems);
    }

    public static List<RoomModel> GetVisibleRoomsFromLink(Document doc, View activeView, RevitLinkInstance linkInstance)
    {
        var linkDoc = linkInstance.GetLinkDocument();
        var transform = linkInstance.GetTotalTransform();

        var viewRange = (activeView as ViewPlan).GetViewRange();

        var topClipId = viewRange.GetLevelId(PlanViewPlane.TopClipPlane);
        var topClip = doc.GetElement(topClipId) as Level;
        var topOffset = viewRange.GetOffset(PlanViewPlane.TopClipPlane);


        var bottomClipId = viewRange.GetLevelId(PlanViewPlane.BottomClipPlane);
        var bottomClip = doc.GetElement(bottomClipId) as Level;
        var bottomOffset = viewRange.GetOffset(PlanViewPlane.BottomClipPlane);


        var cropBox = activeView.CropBox;
        var minPoint = new XYZ(cropBox.Min.X, cropBox.Min.Y, bottomClip.Elevation + bottomOffset);
        var maxPoint = new XYZ(cropBox.Max.X, cropBox.Max.Y, topClip.Elevation + topOffset);

        var outline = new Outline(minPoint, maxPoint);


        var insideFilter = new BoundingBoxIsInsideFilter(outline);
        var intersectFilter = new BoundingBoxIntersectsFilter(outline);
        var combinedFilter = new LogicalOrFilter(insideFilter, intersectFilter);

        var elements = new FilteredElementCollector(linkDoc)
            .OfCategory(BuiltInCategory.OST_Rooms)
            .WherePasses(combinedFilter)
            .ToElements();

        var rooms = new List<RoomModel>();
        foreach (var elem in elements)
        {
            if (elem is Room room)
            {
                rooms.Add(new RoomModel{Name = room.Name, Id = room.UniqueId});
            }
        }
        return rooms;
    }
}