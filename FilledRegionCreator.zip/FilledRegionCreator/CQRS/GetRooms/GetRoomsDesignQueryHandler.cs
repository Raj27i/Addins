﻿using RevitAppFramework.Design;
using FilledRegionCreator.Models;

namespace FilledRegionCreator.CQRS.GetRooms;

public class GetRoomsDesignQueryHandler : IDesignQueryHandler<GetRoomsQuery, GetRoomsQueryResult>
{
    public GetRoomsQueryResult Execute(GetRoomsQuery input, CancellationToken cancellationToken)
    {
        var random = new Random();
        var roomItems = new List<RoomModel>();

        for (int i = 1; i <= 20; i++)
        {
            var room = new RoomModel
            {
                Id = Guid.NewGuid().ToString(),
                Name = $"Room {random.Next(1, 10)}{(char)random.Next('A', 'Z' + 1)}"
            };
            roomItems.Add(room);
        }

        return new(roomItems);
    }
}