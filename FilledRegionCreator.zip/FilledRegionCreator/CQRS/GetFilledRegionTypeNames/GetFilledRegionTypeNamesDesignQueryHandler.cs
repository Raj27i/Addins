﻿using RevitAppFramework.Design;
using FilledRegionCreator.Models;

namespace FilledRegionCreator.CQRS;

internal class GetFilledRegionTypeNamesDesignQueryHandler() : IDesignQueryHandler<GetFilledRegionTypeNamesQuery, GetFilledRegionTypeNamesQueryResult>
{
    public GetFilledRegionTypeNamesQueryResult Execute(GetFilledRegionTypeNamesQuery input, CancellationToken cancellationToken)
    {
        var random = new Random();
        var filledRegionItems = new List<FilledRegionTypeModel>();

        for (int i = 1; i <= 2; i++)
        {
            var filledRegion = new FilledRegionTypeModel
            {
                UniqueId = Guid.NewGuid().ToString(),
                Name = $"Filled region {random.Next(1, 10)}{(char)random.Next('A', 'Z' + 1)}",
            };
            filledRegionItems.Add(filledRegion);
        }

        return new(filledRegionItems);
    }
}