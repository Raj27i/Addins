﻿using FilledRegionCreator.Models;

namespace FilledRegionCreator.CQRS;

public record GetFilledRegionTypeNamesQueryResult(List<FilledRegionTypeModel>? Items);