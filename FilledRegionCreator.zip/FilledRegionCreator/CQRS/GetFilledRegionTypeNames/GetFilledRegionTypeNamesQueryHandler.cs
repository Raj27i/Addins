﻿using FilledRegionCreator.Models;

namespace FilledRegionCreator.CQRS;

public class GetFilledRegionTypeNamesQueryHandler(RevitContext context) : IQueryHandler<GetFilledRegionTypeNamesQuery, GetFilledRegionTypeNamesQueryResult>
{
    public GetFilledRegionTypeNamesQueryResult Execute(GetFilledRegionTypeNamesQuery input, CancellationToken cancellationToken)
    {
        var items = new List<FilledRegionTypeModel>();
        var doc = context.Document;
        if (doc is null)
            return new([]);

        var filledRegionTypes = new FilteredElementCollector(doc)
            .OfClass(typeof(FilledRegionType))
            .OfType<FilledRegionType>();

        foreach (var filledRegionType in filledRegionTypes)
        {
            var typeName = filledRegionType.get_Parameter(BuiltInParameter.SYMBOL_NAME_PARAM).AsString();
            var filledRegionItem = new FilledRegionTypeModel
            {
                Name = typeName,
                UniqueId = filledRegionType.UniqueId
            };
            items.Add(filledRegionItem);
        }
        return new GetFilledRegionTypeNamesQueryResult(items);
    }
}