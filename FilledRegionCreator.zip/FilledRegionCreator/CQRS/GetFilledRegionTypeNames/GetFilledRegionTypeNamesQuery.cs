﻿namespace FilledRegionCreator.CQRS;

public class GetFilledRegionTypeNamesQuery : IQuery<GetFilledRegionTypeNamesQueryResult>;
