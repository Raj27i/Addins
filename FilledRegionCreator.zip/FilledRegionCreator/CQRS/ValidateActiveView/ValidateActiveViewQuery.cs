﻿namespace FilledRegionCreator.CQRS.GetRooms;

public record ValidateActiveViewQuery() : IQuery<ValidateActiveViewQueryResult>;




