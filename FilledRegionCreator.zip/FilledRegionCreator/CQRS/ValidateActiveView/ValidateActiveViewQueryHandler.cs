﻿using FilledRegionCreator.CQRS.GetRooms;

namespace FilledRegionCreator.CQRS.GetRooms;

public class ValidateActiveViewQueryHandler(RevitContext context) : IQueryHandler<ValidateActiveViewQuery, ValidateActiveViewQueryResult>
{
    public ValidateActiveViewQueryResult Execute(ValidateActiveViewQuery input, CancellationToken cancellationToken)
    {
        var doc = context.Document;
        if (doc is null)
            return new(false);

        var activeView = doc.ActiveView;

        if(activeView is not ViewPlan)
            return new(false);
        return new(true);
    }
}