﻿using RevitAppFramework.Design;

namespace FilledRegionCreator.CQRS.GetRooms;

public class ValidateActiveViewDesignQueryHandler : IDesignQueryHandler<ValidateActiveViewQuery, ValidateActiveViewQueryResult>
{
    public ValidateActiveViewQueryResult Execute(ValidateActiveViewQuery input, CancellationToken cancellationToken)
    {
        return new(true);
    }
}