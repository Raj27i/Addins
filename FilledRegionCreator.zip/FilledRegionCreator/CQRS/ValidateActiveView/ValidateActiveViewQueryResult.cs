﻿namespace FilledRegionCreator.CQRS.GetRooms;

public record ValidateActiveViewQueryResult(bool IsValid);