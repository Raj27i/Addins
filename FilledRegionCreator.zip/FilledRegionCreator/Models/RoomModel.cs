﻿namespace FilledRegionCreator.Models;

public class RoomModel
{
    public string Id { get; set; }
    public string Name { get; set; }
    public bool IsSelected { get; set; } 
}