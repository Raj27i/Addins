﻿namespace FilledRegionCreator.Models;

public class LinkModel
{
    public string Name { get; set; }
    public string UniqueId { get; set; }
}