﻿namespace FilledRegionCreator.Models;

public class FilledRegionTypeModel
{
    public string Name { get; set; }
    public string UniqueId { get; set; }
}