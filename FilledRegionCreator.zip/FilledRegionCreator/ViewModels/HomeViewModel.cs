﻿using FilledRegionCreator.CQRS;
using FilledRegionCreator.CQRS.GetRooms;
using FilledRegionCreator.Models;
using System.Collections.ObjectModel;
using System.Windows.Data;

namespace FilledRegionCreator.ViewModels;

public class HomeViewModel : RevitViewModelBase
{

    private readonly IContentDialogService _contentDialogService;

    private readonly ISnackbarService _snackbarService;

    public bool IsLoading
    {
        get => Get<bool>();
        set => Set(value);
    }

    public bool IsActiveViewValid
    {
        get => Get<bool>();
        set => When(value)
            .Changed(RefreshRooms)
            .Set();
    }

    public double Offset
    {
        get => Get<double>();
        set => Set(value);
    }

    private ObservableCollection<FilledRegionTypeModel> _filledRegionItems = new();
    public ObservableCollection<FilledRegionTypeModel> FilledRegionItems
    {
        get => _filledRegionItems;
        set
        {
            _filledRegionItems = value;
            OnPropertyChanged();
        }
    }

    public FilledRegionTypeModel? SelectedFilledRegionItem
    {
        get => Get<FilledRegionTypeModel?>();
        set => When(value)
            .Notify(CreateFilledRegionsCommand)
            .Set();
    }

    private ObservableCollection<LinkModel> _linkItems = new();
    public ObservableCollection<LinkModel> LinkItems
    {
        get => _linkItems;
        set
        {
            _linkItems = value;
            OnPropertyChanged();
        }
    }
    public LinkModel? SelectedLinkItem
    {
        get => Get<LinkModel?>();
        set => When(value)
            .Notify(RefreshRoomsCommand, CreateFilledRegionsCommand)
            .Changed(RefreshRooms)
            .Set();
    }

    private readonly ObservableCollection<RoomModel> _allRoomItems = new();
    public ObservableCollection<RoomModel> AllRoomItems => _allRoomItems;

    public ICollectionView RoomItemsView { get; }

    public string? RoomFilterText
    {
        get => Get<string>();
        set => When(value)
            .Changed(RoomItemsView.Refresh)
            .Set();
    }

    public IFluentCommand RefreshRoomsCommand => Do(RefreshRooms).If(() => SelectedLinkItem != null);


    private async void RefreshRooms()
    {
        await ValidateActiveViewCommand.ExecuteAsync(null);
        if(!IsActiveViewValid)
            return;
        SetRoomItems();
    }

    public HomeViewModel(
        ViewModelBaseDeps dependencies,
        FilledRegionCreatorArgs args,
        IContentDialogService contentDialogService,
        ISnackbarService snackbarService
        ) : base(dependencies)
    {
        _contentDialogService = contentDialogService;
        _snackbarService = snackbarService;

        RoomItemsView = CollectionViewSource.GetDefaultView(AllRoomItems);
        RoomItemsView.Filter = FilterRoomByName;

        LoadAsync();
    }

    private bool FilterRoomByName(object obj)
    {
        if (obj is RoomModel room)
        {
            return string.IsNullOrWhiteSpace(RoomFilterText)
                   || room.Name?.IndexOf(RoomFilterText, StringComparison.OrdinalIgnoreCase) >= 0;
        }
        return false;
    }

    public async void LoadAsync()
    {
        IsLoading = true;
        try
        {
            await GetLinksCommand.ExecuteAsync(null);
            await GetFilledRegionTypesCommand.ExecuteAsync(null);
            await ValidateActiveViewCommand.ExecuteAsync(null);
        }
        catch (Exception e)
        {
            _snackbarService.Show("Error", e.Message, Wpf.Ui.Controls.ControlAppearance.Danger);
        }
        finally
        {
            IsLoading = GetLinksCommand.IsRunning;
        }
    }
    public IAsyncFluentCommand GetLinksCommand =>
        Send<GetLinksQuery, GetLinksQueryResult>()
            .Then(o => o.Links?.ForEach(x => LinkItems.Add(x)));
    public IAsyncFluentCommand GetFilledRegionTypesCommand =>
        Send<GetFilledRegionTypeNamesQuery, GetFilledRegionTypeNamesQueryResult>()
            .Then(o => o.Items?.ForEach(x => FilledRegionItems.Add(x)));

    public IAsyncFluentCommand ValidateActiveViewCommand =>
        Send<ValidateActiveViewQuery, ValidateActiveViewQueryResult>()
            .Then(x =>
            {
                IsActiveViewValid = x.IsValid;
            });
    public IAsyncFluentCommand GetRoomsCommand =>
        Send<GetRoomsQuery, GetRoomsQueryResult>(() => new(SelectedLinkItem?.UniqueId))
            .Then(x =>
            {
                AllRoomItems.Clear();
                x.Rooms?.ForEach(r => AllRoomItems.Add(new RoomModel { Id = r.Id, Name = r.Name }));
                RoomItemsView.Refresh();
            });

    public IAsyncFluentCommand CreateFilledRegionsCommand =>
        Send<CreateFilledRegionsQuery, CreateFilledRegionsQueryResult>(() => new(SelectedFilledRegionItem.UniqueId,
                Offset, SelectedLinkItem.UniqueId, AllRoomItems.Where(x => x.IsSelected).ToList()))
            .If(() => SelectedFilledRegionItem != null && SelectedLinkItem != null)
            .Handle(OnSetCommentsFailed)
            .Then(o =>
                _snackbarService.Show("Status", o.Message, o.Appearance));

    private async Task OnSetCommentsFailed(Exception arg)
    {
        await _contentDialogService.ShowAlertAsync("Error",
            "An error occurred while creating filled regions.",
            "OK");
    }

    private async void SetRoomItems()
    {
        IsLoading = true;
        try
        {
            await GetRoomsCommand.ExecuteAsync(SelectedLinkItem?.UniqueId);
        }
        catch (Exception e)
        {
            _snackbarService.Show("Error", e.Message, Wpf.Ui.Controls.ControlAppearance.Danger);
        }
        finally
        {
            IsLoading = GetRoomsCommand.IsRunning;
        }
    }
}




