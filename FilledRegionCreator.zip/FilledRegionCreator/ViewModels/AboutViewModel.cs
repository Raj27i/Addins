﻿using System.Diagnostics;

namespace FilledRegionCreator.ViewModels;

public class AboutViewModel(ViewModelBaseDeps dependencies, ISnackbarService snackbarService) : RevitViewModelBase(dependencies)
{
    public IFluentCommand ShowWikiCommand => Do(OpenWiki);
    
    private void OpenWiki()
    {
        var wikiUrl = "https://wiki.cowitools.com/en/Assistant/Develop/DotnetExtension/FilledRegionCreator";
        var startInfo = new ProcessStartInfo
        {
            FileName = wikiUrl,
            UseShellExecute = true,
            Verb = "open"
        };

        try
        {
            Process.Start(startInfo);
        }
        catch (Exception ex)
        {
            // Display error notification using the snackbar service
            snackbarService.Show("Error", $"Failed to open wiki: {ex.Message}", Wpf.Ui.Controls.ControlAppearance.Danger);
        }
    }
}
