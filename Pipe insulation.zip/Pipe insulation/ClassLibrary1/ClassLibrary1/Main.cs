﻿using System;
using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Mechanical;
using Autodesk.Revit.DB.Plumbing;
using Autodesk.Revit.UI;

namespace PipeInsulationAddin
{
    [Transaction(TransactionMode.Manual)]
    public class PipeInsulationTool : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            UIApplication uiapp = commandData.Application;
            UIDocument uidoc = uiapp.ActiveUIDocument;
            Document doc = uidoc.Document;

            try
            {
                // Get all system types available in the project
                List<PipingSystemType> systemTypes = new FilteredElementCollector(doc)
                    .OfClass(typeof(PipingSystemType))
                    .Cast<PipingSystemType>()
                    .OrderBy(st => st.Name)
                    .ToList();

                if (systemTypes.Count == 0)
                {
                    TaskDialog.Show("Error", "No piping system types found in this project.");
                    return Result.Failed;
                }

                // Get all insulation types available in the project
                List<PipeInsulationType> insulationTypes = new FilteredElementCollector(doc)
                    .OfClass(typeof(PipeInsulationType))
                    .Cast<PipeInsulationType>()
                    .OrderBy(it => it.Name)
                    .ToList();

                if (insulationTypes.Count == 0)
                {
                    TaskDialog.Show("Error", "No pipe insulation types found in this project.");
                    return Result.Failed;
                }

                // Open dialog
                PipeInsulationDialog dialog = new PipeInsulationDialog(doc, systemTypes, insulationTypes);
                dialog.ShowDialog();

                // Check if the user clicked OK
                if (dialog.WasOkClicked)
                {
                    // Get the selected values from the dialog
                    PipingSystemType selectedSystemType = dialog.SelectedSystemType;
                    PipeInsulationType selectedInsulationType = dialog.SelectedInsulationType;
                    Dictionary<double, double> diameterToThickness = dialog.GetDiameterToThickness();

                    if (selectedSystemType == null || selectedInsulationType == null || diameterToThickness.Count == 0)
                    {
                        TaskDialog.Show("Error", "Invalid selection. Please select a system type, insulation type, and set thicknesses.");
                        return Result.Failed;
                    }

                    using (Transaction trans = new Transaction(doc, "Apply Pipe Insulation"))
                    {
                        trans.Start();

                        int removed = 0;
                        int created = 0;

                        // Get all pipes with this system type
                        List<Pipe> pipes = new FilteredElementCollector(doc)
                            .OfClass(typeof(Pipe))
                            .Cast<Pipe>()
                            .Where(p => p.MEPSystem != null && p.MEPSystem.GetTypeId().Value == selectedSystemType.Id.Value)
                            .ToList();

                        foreach (Pipe pipe in pipes)
                        {
                            double diameter = pipe.Diameter;
                            if (diameterToThickness.ContainsKey(diameter) && diameterToThickness[diameter] > 0)
                            {
                                double thickness = diameterToThickness[diameter] / 304.8; // Convert mm to feet

                                // Remove any existing insulation
                                ICollection<ElementId> existingInsulations = PipeInsulation.GetInsulationIds(doc, pipe.Id);
                                if (existingInsulations.Count > 0)
                                {
                                    doc.Delete(existingInsulations);
                                    removed += existingInsulations.Count;
                                }

                                // Create new insulation
                                PipeInsulation.Create(doc, pipe.Id, selectedInsulationType.Id, thickness);
                                created++;
                            }
                        }

                        // Get all fittings with this system type
                        List<FamilyInstance> fittings = GetFittingsInSystem(doc, selectedSystemType.Id);

                        foreach (FamilyInstance fitting in fittings)
                        {
                            double? fittingDiameter = GetFittingDiameter(fitting);
                            if (fittingDiameter.HasValue && diameterToThickness.ContainsKey(fittingDiameter.Value) && diameterToThickness[fittingDiameter.Value] > 0)
                            {
                                double thickness = diameterToThickness[fittingDiameter.Value] / 304.8; // Convert mm to feet

                                // Remove any existing insulation
                                ICollection<ElementId> existingInsulations = PipeInsulation.GetInsulationIds(doc, fitting.Id);
                                if (existingInsulations.Count > 0)
                                {
                                    doc.Delete(existingInsulations);
                                    removed += existingInsulations.Count;
                                }

                                // Create new insulation
                                PipeInsulation.Create(doc, fitting.Id, selectedInsulationType.Id, thickness);
                                created++;
                            }
                        }

                        trans.Commit();

                        TaskDialog.Show("Success",
                            $"Pipe insulation completed.\n" +
                            $"- {removed} existing insulations removed\n" +
                            $"- {created} new insulations created");

                        return Result.Succeeded;
                    }
                }

                return Result.Cancelled;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                TaskDialog.Show("Error", $"An error occurred: {ex.Message}");
                return Result.Failed;
            }
        }

        private List<FamilyInstance> GetFittingsInSystem(Document doc, ElementId systemTypeId)
        {
            List<FamilyInstance> fittings = new FilteredElementCollector(doc)
                .OfClass(typeof(FamilyInstance))
                .Cast<FamilyInstance>()
                .Where(f => f.MEPModel != null && f.MEPModel is MechanicalFitting)
                .ToList();

            // Filter fittings by checking their connectors for the system type
            return fittings.Where(f =>
            {
                if (f.MEPModel.ConnectorManager == null)
                    return false;

                foreach (Connector conn in f.MEPModel.ConnectorManager.Connectors)
                {
                    if (conn.MEPSystem != null && conn.MEPSystem.GetTypeId().Value == systemTypeId.Value)
                        return true;
                }
                return false;
            }).ToList();
        }

        private double? GetFittingDiameter(FamilyInstance fitting)
        {
            try
            {
                if (fitting.MEPModel == null || fitting.MEPModel.ConnectorManager == null)
                    return null;

                ConnectorSet connectorSet = fitting.MEPModel.ConnectorManager.Connectors;

                double maxDiameter = 0;
                bool hasDiameter = false;

                foreach (Connector connector in connectorSet)
                {
                    if (connector.Shape == ConnectorProfileType.Round)
                    {
                        double diameter = connector.Radius * 2; // Diameter = 2 * Radius
                        if (diameter > maxDiameter)
                        {
                            maxDiameter = diameter;
                            hasDiameter = true;
                        }
                    }
                }

                if (hasDiameter)
                    return maxDiameter;
            }
            catch
            {
                // Some fittings might not have accessible connectors
            }

            return null;
        }
    }
}