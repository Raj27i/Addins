﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Plumbing;

namespace PipeInsulationAddin
{
    /// <summary>
    /// Interaction logic for PipeInsulationDialog.xaml
    /// </summary>
    public partial class PipeInsulationDialog : Window
    {
        private Document _doc;
        public bool WasOkClicked { get; private set; } = false;
        public PipingSystemType SelectedSystemType => SystemTypeComboBox.SelectedItem as PipingSystemType;
        public PipeInsulationType SelectedInsulationType => InsulationTypeComboBox.SelectedItem as PipeInsulationType;
        public ObservableCollection<PipeDiameterItem> PipeDiameterItems { get; private set; }

        public PipeInsulationDialog(Document doc, List<PipingSystemType> systemTypes, List<PipeInsulationType> insulationTypes)
        {
            InitializeComponent();

            _doc = doc;
            PipeDiameterItems = new ObservableCollection<PipeDiameterItem>();
            PipeDiameterGrid.ItemsSource = PipeDiameterItems;

            // Initialize combo boxes
            SystemTypeComboBox.ItemsSource = systemTypes;
            InsulationTypeComboBox.ItemsSource = insulationTypes;

            if (systemTypes.Count > 0)
                SystemTypeComboBox.SelectedIndex = 0;

            if (insulationTypes.Count > 0)
                InsulationTypeComboBox.SelectedIndex = 0;
        }

        private void SystemTypeComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (SystemTypeComboBox.SelectedItem == null)
                return;

            PipeDiameterItems.Clear();
            LoadPipesAndFittings();
        }

        private void LoadPipesAndFittings()
        {
            if (SelectedSystemType == null)
                return;

            ElementId systemTypeId = SelectedSystemType.Id;

            // Get all pipes with the selected system type
            List<Pipe> pipes = new FilteredElementCollector(_doc)
                .OfClass(typeof(Pipe))
                .Cast<Pipe>()
                .Where(p => p.MEPSystem != null && p.MEPSystem.GetTypeId().Value == systemTypeId.Value)
                .ToList();

            // Update the pipe count text
            PipeCountTextBlock.Text = $"Found {pipes.Count} pipes in system";

            // Group pipes by diameter
            var pipesByDiameter = new Dictionary<double, List<ElementId>>();

            foreach (Pipe pipe in pipes)
            {
                double diameter = pipe.Diameter;
                if (!pipesByDiameter.ContainsKey(diameter))
                    pipesByDiameter[diameter] = new List<ElementId>();

                pipesByDiameter[diameter].Add(pipe.Id);
            }

            // Sort by diameter and create items for the grid
            foreach (var diameter in pipesByDiameter.Keys.OrderBy(d => d))
            {
                // Convert diameter from feet to mm for display
                double diameterMM = UnitUtils.ConvertFromInternalUnits(diameter, UnitTypeId.Millimeters);

                // Check for existing insulation and get average thickness
                double existingThickness = GetAverageInsulationThickness(pipesByDiameter[diameter]);

                // Use existing thickness if found, otherwise default to 25mm
                double thicknessToUse = existingThickness > 0 ? existingThickness : 25;

                PipeDiameterItems.Add(new PipeDiameterItem
                {
                    Diameter = diameter,
                    DiameterDisplay = $"{Math.Round(diameterMM)} mm",
                    Elements = pipesByDiameter[diameter],
                    ElementCount = pipesByDiameter[diameter].Count,
                    InsulationThickness = thicknessToUse,
                    HasExistingInsulation = existingThickness > 0
                });
            }
        }

        private double GetAverageInsulationThickness(List<ElementId> elementIds)
        {
            if (elementIds == null || elementIds.Count == 0)
                return 0;

            double totalThickness = 0;
            int insulatedCount = 0;

            foreach (ElementId elementId in elementIds)
            {
                foreach (ElementId insulationId in PipeInsulation.GetInsulationIds(_doc, elementId))
                {
                    PipeInsulation insulation = _doc.GetElement(insulationId) as PipeInsulation;
                    if (insulation != null)
                    {
                        // Convert thickness from feet to mm
                        double thicknessMM = UnitUtils.ConvertFromInternalUnits(insulation.Thickness, UnitTypeId.Millimeters);
                        totalThickness += thicknessMM;
                        insulatedCount++;
                        break; // Just use the first insulation if multiple exist
                    }
                }
            }

            if (insulatedCount > 0)
                return Math.Round(totalThickness / insulatedCount); // Return average thickness in mm

            return 0; // No insulation found
        }

        private void ApplyToAllButton_Click(object sender, RoutedEventArgs e)
        {
            if (double.TryParse(ApplyToAllTextBox.Text, out double thickness))
            {
                foreach (var item in PipeDiameterItems)
                {
                    item.InsulationThickness = thickness;
                }

                // Refresh the grid to show updated values
                PipeDiameterGrid.Items.Refresh();
            }
            else
            {
                MessageBox.Show("Please enter a valid thickness value.");
            }
        }

        private void OkButton_Click(object sender, RoutedEventArgs e)
        {
            if (InsulationTypeComboBox.SelectedItem == null)
            {
                MessageBox.Show("Please select an insulation type.");
                return;
            }

            if (PipeDiameterItems.Count == 0)
            {
                MessageBox.Show("No pipes found in the selected system.");
                return;
            }

            WasOkClicked = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            WasOkClicked = false;
            Close();
        }

        public Dictionary<double, double> GetDiameterToThickness()
        {
            Dictionary<double, double> result = new Dictionary<double, double>();

            foreach (var item in PipeDiameterItems)
            {
                result[item.Diameter] = item.InsulationThickness;
            }

            return result;
        }
    }

    public class PipeDiameterItem : INotifyPropertyChanged
    {
        private double _insulationThickness;
        private bool _hasExistingInsulation;

        public double Diameter { get; set; }
        public string DiameterDisplay { get; set; }
        public List<ElementId> Elements { get; set; }
        public int ElementCount { get; set; }

        public bool HasExistingInsulation
        {
            get => _hasExistingInsulation;
            set
            {
                if (_hasExistingInsulation != value)
                {
                    _hasExistingInsulation = value;
                    OnPropertyChanged("HasExistingInsulation");
                    OnPropertyChanged("StatusText");
                    OnPropertyChanged("StatusColor");
                }
            }
        }

        public string StatusText
        {
            get => HasExistingInsulation ? "Exists" : "New";
        }

        public Brush StatusColor
        {
            get => HasExistingInsulation ? Brushes.Green : Brushes.Blue;
        }

        public double InsulationThickness
        {
            get => _insulationThickness;
            set
            {
                if (_insulationThickness != value)
                {
                    _insulationThickness = value;
                    OnPropertyChanged("InsulationThickness");
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}